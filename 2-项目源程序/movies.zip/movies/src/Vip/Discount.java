package Vip;
/***********************************************************************
 * Module:  Discount.java
 * Author:  WZBC
 * Purpose: Defines the Class Discount
 ***********************************************************************/

import java.util.*;

import User.Play;

/** @pdOid 9ba2d08e-ac37-424f-bdea-9272edaef8a2 */
public abstract class Discount {
   /** @param ticket
    * @pdOid 8dd9f03f-ccd1-4be4-9ad4-85ec14baa88a */
   public abstract String count(String tic_price);

}